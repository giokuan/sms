<main class="flex flex-col items-center flex-1 px-4 pt-6 justify-center">

    <div class="w-full p-10 my-6 overflow-hidden bg-slate-200 bg-opacity-90 rounded-md shadow-md sm:max-w-xl dark:bg-dark-eval-1">
        {{ $slot }}
    </div>
</main>