
<html>
<head>
    @livewireStyles
</head>
<body>
  
    
<div class="p-4">
    <livewire:calendar />
    @livewireScripts
    @stack('scripts')

</div>

  
</body>
</html>

