

@extends('partials.__sidebar')
@section('content')	
<h1>Teachers Dashboard</h1>


@endsection


